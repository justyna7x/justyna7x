package com.group12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScrumGroup12Application {

	public static void main(String[] args) {
		SpringApplication.run(ScrumGroup12Application.class, args);
	}

}
