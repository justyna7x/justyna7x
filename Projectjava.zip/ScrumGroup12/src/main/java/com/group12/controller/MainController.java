package com.group12.controller;

import com.group12.model.User;
import com.group12.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
    @Autowired
    UserRepo userRepo;
    
    @RequestMapping("/")
    public String login(Model model) {
		model.addAttribute("user", new User());
		return "security/login";
    	
    }
    
    /// changed the URL mapping of the below function from "/" to "/home"
        
    @GetMapping("/home")
    public String index(Model model) {
        model.addAttribute("users", userRepo.findAll());
        return "/index";
    }


}
