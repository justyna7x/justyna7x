package com.group12.controller;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.group12.model.User;
import com.group12.repo.UserRepo;


@Controller
public class AuthenticationController {

	@Autowired
	UserRepo repo;
	
	@RequestMapping("/signup")
	public String signUser(Model model) {
		model.addAttribute("user", new User());
		return "security/signup";
	}
	
	@RequestMapping("/store")
	public String storeUser(Model model, @ModelAttribute User user) {
		user = repo.save(user);
		model.addAttribute("user", user);
		// redirect to home page 
		return "redirect:/home";
	}
	@RequestMapping("/forgotpassword")
	public String forgotpassword(Model model, @ModelAttribute User user) {
		model.addAttribute("user");
		
		
		return "security/forgotpassword";
	}
	@RequestMapping("/storepassword")
	public String storePassword(Model model, @ModelAttribute User user) {
		user = repo.save(user);
		model.addAttribute("user", user);
		
		return "redirect:/home";
	}
}
