DROP SCHEMA IF exists group12;
CREATE SCHEMA group12;

CREATE TABLE group12.users (
	id INT NOT NULL auto_increment,
    email VARCHAR(20),
    password VARCHAR(30),
    PRIMARY KEY (id)
);

INSERT INTO group12.users (email, password) values ("test@test.com", "testPassword");

DROP USER IF EXISTS 'group12Member'@'localhost';

CREATE USER 'group12Member'@'localhost' IDENTIFIED BY 'testPassword1';

GRANT ALL PRIVILEGES ON group12.* TO 'group12Member'@'localhost';